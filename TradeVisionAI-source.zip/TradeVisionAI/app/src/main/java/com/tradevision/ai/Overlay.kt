package com.tradevision.ai

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Компактное плавающее окно поверх других приложений. */
class Overlay(
    private val ctx: Context,
    private val st: Prefs,
    private val onRefresh: () -> Unit,
    private val onPause: () -> Unit,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx)
    private val body = LinearLayout(ctx)

    private val tvAsset = label(12f, Ui.MUTED)
    private val tvSignal = label(30f, Ui.WAIT, bold = true)
    private val tvTrend = label(12f, Ui.TEXT)
    private val tvTf = label(12f, Ui.MUTED)
    private val tvTime = label(11f, Ui.MUTED)
    private val btnPause = button("⏸ Пауза")

    /** Границы окна на экране (l, t, r, b) — чтобы анализатор не учитывал само окно. */
    @Volatile var bounds: IntArray? = null

    private val lp = WindowManager.LayoutParams(
        Ui.dp(ctx, 190),
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 240
    }

    private var shown = false

    init {
        val pad = Ui.dp(ctx, 10)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        root.background = Ui.rounded(ctx, 0xFF0B0E11.toInt(), 14)

        // Заголовок: название (им же перетаскиваем), свернуть, закрыть.
        val header = LinearLayout(ctx)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        val title = label(13f, Ui.ACCENT, bold = true)
        title.text = "TradeVision AI"
        title.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        title.setOnTouchListener(dragListener())

        val btnMin = label(18f, Ui.TEXT)
        btnMin.text = "–"
        btnMin.setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 10), 0)
        btnMin.setOnClickListener {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        val btnClose = label(16f, Ui.SELL)
        btnClose.text = "✕"
        btnClose.setPadding(Ui.dp(ctx, 6), 0, Ui.dp(ctx, 2), 0)
        btnClose.setOnClickListener { onClose() }

        header.addView(title)
        header.addView(btnMin)
        header.addView(btnClose)

        body.orientation = LinearLayout.VERTICAL
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val btnRefresh = button("⟳ Обновить")
        btnRefresh.setOnClickListener { onRefresh() }
        btnPause.setOnClickListener { onPause() }
        val half = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 6, 2, 0) } }
        btnRefresh.layoutParams = half()
        btnPause.layoutParams = half()
        row.addView(btnRefresh)
        row.addView(btnPause)

        body.addView(tvAsset)
        body.addView(tvSignal)
        body.addView(tvTrend)
        body.addView(tvTf)
        body.addView(tvTime)
        body.addView(row)

        root.addView(header)
        root.addView(body)

        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateBounds() }
        update(null, false)
    }

    fun show() {
        if (shown) return
        wm.addView(root, lp)
        shown = true
    }

    fun remove() {
        if (!shown) return
        try { wm.removeView(root) } catch (_: Exception) { }
        shown = false
    }

    fun update(sig: Signal?, paused: Boolean) {
        root.alpha = st.opacity / 100f
        tvAsset.text = "Актив: ${st.asset}"
        tvTf.text = "Таймфрейм: ${st.timeframe}"
        val dir = sig?.direction ?: "—"
        tvSignal.text = if (paused) "ПАУЗА" else dir
        tvSignal.setTextColor(if (paused) Ui.WAIT else Ui.dirColor(dir))
        val trend = sig?.trend ?: "—"
        tvTrend.text = "Тренд: $trend"
        tvTrend.setTextColor(Ui.trendColor(trend))
        tvTime.text = "Анализ: " + (sig?.let { SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(it.time)) } ?: "—")
        btnPause.text = if (paused) "▶ Старт" else "⏸ Пауза"
    }

    private fun updateBounds() {
        bounds = intArrayOf(lp.x, lp.y, lp.x + root.width, lp.y + root.height)
    }

    private fun dragListener(): View.OnTouchListener {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    if (shown) wm.updateViewLayout(root, lp)
                    updateBounds()
                    true
                }
                else -> false
            }
        }
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(text: String): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = 11f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            val p = Ui.dp(ctx, 6)
            setPadding(p, p, p, p)
            background = Ui.rounded(ctx, 0xFF232B36.toInt(), 8)
        }
}
