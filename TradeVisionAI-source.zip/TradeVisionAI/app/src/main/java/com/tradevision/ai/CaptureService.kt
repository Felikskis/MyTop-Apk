package com.tradevision.ai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Foreground-сервис: получает кадры экрана через MediaProjection (после явного
 * разрешения пользователя), анализирует их локально и показывает результат в плавающем окне.
 * Данные никуда не отправляются. Сделки не совершаются.
 */
class CaptureService : Service() {

    private lateinit var prefs: Prefs
    private val analyzer = ChartAnalyzer()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var bgThread: HandlerThread
    private lateinit var bg: Handler

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: Overlay? = null

    private var capW = 0
    private var capH = 0
    private var dpi = 0
    private var scale = 1f
    private var lastBitmap: Bitmap? = null
    private var closed = false

    private val loop = object : Runnable {
        override fun run() {
            if (!AppState.running || closed) return
            if (!AppState.paused) requestAnalysis()
            main.postDelayed(this, prefs.intervalSec * 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        bgThread = HandlerThread("tv-analysis").also { it.start() }
        bg = Handler(bgThread.looper)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY // уже запущено

        // Android 14: foreground-сервис типа mediaProjection нужно запустить ДО getMediaProjection.
        startForegroundCompat()

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else
            intent.getParcelableExtra("data")
        if (code != Activity.RESULT_OK || data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        // Android 14: callback нужно зарегистрировать до createVirtualDisplay.
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { shutdown() }
            }
        }, main)

        readScreenSize()
        reader = newReader()
        display = proj.createVirtualDisplay(
            "TradeVisionCapture", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, bg
        )

        overlay = Overlay(this, prefs, { requestAnalysis() }, { togglePause() }, { shutdown() }).also { it.show() }

        AppState.running = true
        AppState.paused = false
        AppState.last = null
        AppState.notifyChanged()
        main.postDelayed(loop, 1500)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Захват экрана", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("TradeVision AI")
            .setContentText("Анализ экрана активен. Остановить можно в приложении или в окне.")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        scale = if (dm.widthPixels > 1080) 1080f / dm.widthPixels else 1f
        capW = (dm.widthPixels * scale).toInt()
        capH = (dm.heightPixels * scale).toInt()
        dpi = dm.densityDpi
    }

    private fun newReader(): ImageReader =
        ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)

    /** Если экран повернули — подгоняем размер захвата. */
    @Suppress("DEPRECATION")
    private fun checkRotation() {
        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val sc = if (dm.widthPixels > 1080) 1080f / dm.widthPixels else 1f
        val w = (dm.widthPixels * sc).toInt()
        val h = (dm.heightPixels * sc).toInt()
        if (w == capW && h == capH) return
        scale = sc; capW = w; capH = h; dpi = dm.densityDpi
        val old = reader
        reader = newReader()
        display?.resize(capW, capH, dpi)
        display?.setSurface(reader!!.surface)
        old?.close()
        lastBitmap = null
    }

    private fun togglePause() {
        AppState.paused = !AppState.paused
        overlay?.update(AppState.last, AppState.paused)
        AppState.notifyChanged()
    }

    private fun requestAnalysis() {
        bg.post {
            if (closed) return@post
            try {
                checkRotation()
                val image: Image? = reader?.acquireLatestImage()
                if (image != null) {
                    val bmp = try { toBitmap(image) } finally { image.close() }
                    lastBitmap = bmp
                }
                val bmp = lastBitmap
                if (bmp == null) {
                    publish(Analysis("NO DATA", "—", "Нет кадра с экрана. Откройте график и подождите."))
                    return@post
                }
                val w = bmp.width
                val h = bmp.height
                val px = IntArray(w * h)
                bmp.getPixels(px, 0, w, 0, 0, w, h)
                val ob = overlay?.bounds
                val ignore = ob?.let {
                    intArrayOf(
                        ((it[0] - 8) * scale).toInt(), ((it[1] - 8) * scale).toInt(),
                        ((it[2] + 8) * scale).toInt(), ((it[3] + 8) * scale).toInt()
                    )
                }
                publish(analyzer.analyze(px, w, h, ignore, prefs))
            } catch (e: Exception) {
                publish(Analysis("NO DATA", "—", "Ошибка анализа: ${e.javaClass.simpleName}"))
            }
        }
    }

    private fun toBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val full = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        return if (rowPadding == 0) full else Bitmap.createBitmap(full, 0, 0, image.width, image.height)
    }

    private fun publish(a: Analysis) {
        val sig = Signal(System.currentTimeMillis(), prefs.asset, prefs.timeframe, a.direction, a.trend, a.note)
        AppState.last = sig
        if (a.direction != "NO DATA") prefs.addHistory(sig)
        main.post {
            overlay?.update(sig, AppState.paused)
            AppState.notifyChanged()
        }
    }

    private fun shutdown() {
        if (closed) return
        closed = true
        AppState.running = false
        AppState.paused = false
        main.removeCallbacks(loop)
        overlay?.remove()
        overlay = null
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        bgThread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        AppState.notifyChanged()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.tradevision.ai.STOP"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1
    }
}
