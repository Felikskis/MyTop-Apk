package com.tradevision.ai

import kotlin.math.max
import kotlin.math.min

data class Candle(
    val x: Int,
    val width: Int,
    val open: Float,
    val close: Float,
    val high: Float,
    val low: Float,
    val bull: Boolean
)

data class Analysis(val direction: String, val trend: String, val note: String)

/**
 * Алгоритмический анализ скриншота графика. НЕ нейросеть и НЕ обученная модель.
 *
 * 1. Находит на кадре зелёные и красные вертикальные объекты (свечи) по цвету пикселей.
 * 2. Переводит их в относительные цены (0..1 по высоте экрана). Реальные цены не читаются
 *    (нет OCR шкалы), поэтому используется только форма движения.
 * 3. Считает EMA / RSI / MACD / уровни по этим относительным ценам и голосованием
 *    выдаёт BUY / SELL / WAIT. Вероятность успеха не оценивается.
 */
class ChartAnalyzer {

    fun analyze(px: IntArray, w: Int, h: Int, ignore: IntArray?, st: Prefs): Analysis {
        val candles = detectCandles(px, w, h, ignore)
        if (candles.size < MIN_CANDLES) {
            return Analysis(
                "NO DATA", "—",
                "График не распознан: найдено свечей ${candles.size}, нужно не менее $MIN_CANDLES. " +
                    "Откройте график крупно, с красными и зелёными свечами."
            )
        }

        val closes = candles.map { it.close }
        val n = closes.size
        val range = max(candles.maxOf { it.high } - candles.minOf { it.low }, 1e-4f)

        // Тренд: наклон линейной регрессии по последним закрытиям, в долях диапазона.
        val m = min(30, n)
        val ys = closes.takeLast(m)
        val xbar = (m - 1) / 2f
        val ybar = ys.sum() / m
        var num = 0f
        var den = 0f
        for (i in 0 until m) {
            num += (i - xbar) * (ys[i] - ybar)
            den += (i - xbar) * (i - xbar)
        }
        val slope = if (den == 0f) 0f else num / den
        val move = slope * (m - 1) / range
        val thr = when (st.sensitivity) { 1 -> 0.30f; 3 -> 0.12f; else -> 0.20f }
        val trend = if (move > thr) "UP" else if (move < -thr) "DOWN" else "SIDEWAYS"

        var score = 0
        var voters = 0
        val parts = ArrayList<String>()
        val skipped = ArrayList<String>()

        voters++
        if (trend == "UP") score++ else if (trend == "DOWN") score--
        parts.add("тренд $trend")

        if (st.useEma) {
            if (n >= 21) {
                val e9 = ema(closes, 9).last()
                val e21 = ema(closes, 21).last()
                voters++
                score += if (e9 > e21) 1 else -1
                parts.add(if (e9 > e21) "EMA9>EMA21" else "EMA9<EMA21")
            } else skipped.add("EMA")
        }

        if (st.useRsi) {
            if (n >= 15) {
                val r = rsi(closes, 14)
                voters++
                if (r > 70f) score-- else if (r < 30f) score++
                parts.add("RSI ${r.toInt()}")
            } else skipped.add("RSI")
        }

        if (st.useMacd) {
            if (n >= 35) {
                val e12 = ema(closes, 12)
                val e26 = ema(closes, 26)
                val line = List(n) { e12[it] - e26[it] }
                val sig = ema(line, 9)
                val hist = line.last() - sig.last()
                val prev = line[n - 2] - sig[n - 2]
                voters++
                if (hist > 0f && hist >= prev) { score++; parts.add("MACD вверх") }
                else if (hist < 0f && hist <= prev) { score--; parts.add("MACD вниз") }
                else parts.add("MACD нейтр.")
            } else skipped.add("MACD")
        }

        if (st.useSr) {
            if (n >= 20) {
                val (support, resistance) = levels(candles, closes.last())
                val tol = range * 0.04f
                var s = 0
                if (support != null && closes.last() - support <= tol) s++
                if (resistance != null && resistance - closes.last() <= tol) s--
                voters++
                score += s
                parts.add(if (s > 0) "у поддержки" else if (s < 0) "у сопротивления" else "вне уровней")
            } else skipped.add("уровни")
        }

        var needed = when (st.sensitivity) { 1 -> 3; 3 -> 1; else -> 2 }
        needed = min(needed, voters)
        val direction = if (score >= needed) "BUY" else if (score <= -needed) "SELL" else "WAIT"

        val note = buildString {
            append("Алгоритмический анализ по $n свечам (не вероятность успеха). ")
            append("Баланс голосов: $score из $voters. ")
            append(parts.joinToString(", "))
            if (skipped.isNotEmpty()) append(". Мало свечей для: ${skipped.joinToString(", ")}")
        }
        return Analysis(direction, trend, note)
    }

    // ---------- Распознавание свечей ----------

    /** 1 = зелёный, 2 = красный, 0 = не свеча. */
    private fun cls(c: Int): Int {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        if (mx < 110) return 0
        if ((mx - mn).toFloat() / mx < 0.5f) return 0
        if (g == mx && g - r > 50 && g - b > 20) return 1
        if (r == mx && r - g > 90 && kotlin.math.abs(g - b) < 70) return 2
        return 0
    }

    private fun detectCandles(px: IntArray, w: Int, h: Int, ign: IntArray?): List<Candle> {
        val gCnt = IntArray(w)
        val rCnt = IntArray(w)
        val gMin = IntArray(w) { Int.MAX_VALUE }
        val gMax = IntArray(w) { -1 }
        val rMin = IntArray(w) { Int.MAX_VALUE }
        val rMax = IntArray(w) { -1 }

        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (ign != null && x >= ign[0] && x < ign[2] && y >= ign[1] && y < ign[3]) continue
                when (cls(px[row + x])) {
                    1 -> { gCnt[x]++; if (y < gMin[x]) gMin[x] = y; if (y > gMax[x]) gMax[x] = y }
                    2 -> { rCnt[x]++; if (y < rMin[x]) rMin[x] = y; if (y > rMax[x]) rMax[x] = y }
                }
            }
        }

        val col = IntArray(w)
        for (x in 0 until w) {
            col[x] = if (gCnt[x] >= 3 && gCnt[x] >= rCnt[x]) 1 else if (rCnt[x] >= 3) 2 else 0
        }

        val maxW = max(3, (w * 0.05f).toInt())
        val raw = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            if (col[x] == 0) { x++; continue }
            val c = col[x]
            var e = x
            while (e + 1 < w && col[e + 1] == c) e++
            val width = e - x + 1
            if (width <= maxW) {
                val cnt = if (c == 1) gCnt else rCnt
                val mn = if (c == 1) gMin else rMin
                val mxArr = if (c == 1) gMax else rMax
                var maxCnt = 0
                for (i in x..e) maxCnt = max(maxCnt, cnt[i])
                var bTop = Int.MAX_VALUE
                var bBot = -1
                var hi = Int.MAX_VALUE
                var lo = -1
                for (i in x..e) {
                    hi = min(hi, mn[i])
                    lo = max(lo, mxArr[i])
                    if (cnt[i] * 2 >= maxCnt) {
                        bTop = min(bTop, mn[i])
                        bBot = max(bBot, mxArr[i])
                    }
                }
                if (lo - hi >= 2 && bBot >= 0) {
                    fun p(y: Int) = (h - y).toFloat() / h
                    val bull = c == 1
                    raw.add(
                        Candle(
                            x = (x + e) / 2, width = width,
                            open = if (bull) p(bBot) else p(bTop),
                            close = if (bull) p(bTop) else p(bBot),
                            high = p(hi), low = p(lo), bull = bull
                        )
                    )
                }
            }
            x = e + 1
        }
        if (raw.size < 2) return raw

        // Оставляем свечи типичной ширины.
        val mw = raw.map { it.width }.sorted()[raw.size / 2]
        val sized = raw.filter { it.width >= max(1, mw / 2) && it.width <= mw * 2 }
        if (sized.size < 2) return sized

        // Самая длинная цепочка свечей с похожим шагом по X (отсекает кнопки и иконки).
        val dxs = sized.zipWithNext { a, b -> b.x - a.x }.sorted()
        val medDx = max(1, dxs[dxs.size / 2])
        var bestStart = 0
        var bestLen = 0
        var start = 0
        for (i in 1..sized.size) {
            val broken = i == sized.size || sized[i].x - sized[i - 1].x > medDx * 3
            if (broken) {
                if (i - start > bestLen) { bestLen = i - start; bestStart = start }
                start = i
            }
        }
        return sized.subList(bestStart, bestStart + bestLen)
    }

    // ---------- Индикаторы ----------

    private fun ema(v: List<Float>, p: Int): List<Float> {
        val k = 2f / (p + 1)
        val out = ArrayList<Float>(v.size)
        var prev = v[0]
        out.add(prev)
        for (i in 1 until v.size) {
            prev = v[i] * k + prev * (1 - k)
            out.add(prev)
        }
        return out
    }

    private fun rsi(v: List<Float>, p: Int): Float {
        var g = 0f
        var l = 0f
        for (i in 1..p) {
            val d = v[i] - v[i - 1]
            if (d > 0) g += d else l -= d
        }
        g /= p
        l /= p
        for (i in p + 1 until v.size) {
            val d = v[i] - v[i - 1]
            g = (g * (p - 1) + max(d, 0f)) / p
            l = (l * (p - 1) + max(-d, 0f)) / p
        }
        return if (l == 0f) 100f else 100f - 100f / (1f + g / l)
    }

    /** Ближайшие поддержка (ниже цены) и сопротивление (выше цены) по локальным экстремумам. */
    private fun levels(c: List<Candle>, price: Float): Pair<Float?, Float?> {
        val from = max(0, c.size - 60)
        val seg = c.subList(from, c.size)
        var support: Float? = null
        var resistance: Float? = null
        for (i in 3 until seg.size - 3) {
            var isHigh = true
            var isLow = true
            for (j in i - 3..i + 3) {
                if (seg[j].high > seg[i].high) isHigh = false
                if (seg[j].low < seg[i].low) isLow = false
            }
            if (isHigh && seg[i].high > price && (resistance == null || seg[i].high < resistance)) resistance = seg[i].high
            if (isLow && seg[i].low < price && (support == null || seg[i].low > support)) support = seg[i].low
        }
        return Pair(support, resistance)
    }

    companion object {
        const val MIN_CANDLES = 15
    }
}
