package com.tradevision.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Настройки и история сигналов. Всё хранится только на устройстве. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("tradevision", Context.MODE_PRIVATE)

    var asset: String
        get() = sp.getString("asset", ASSETS[0]) ?: ASSETS[0]
        set(v) { sp.edit().putString("asset", v).apply() }

    var timeframe: String
        get() = sp.getString("tf", TIMEFRAMES[1]) ?: TIMEFRAMES[1]
        set(v) { sp.edit().putString("tf", v).apply() }

    var intervalSec: Int
        get() = sp.getInt("interval", 5)
        set(v) { sp.edit().putInt("interval", v).apply() }

    /** 1 = осторожно (мало сигналов), 3 = чувствительно (много сигналов). */
    var sensitivity: Int
        get() = sp.getInt("sens", 2)
        set(v) { sp.edit().putInt("sens", v).apply() }

    var useEma: Boolean
        get() = sp.getBoolean("ema", true)
        set(v) { sp.edit().putBoolean("ema", v).apply() }

    var useRsi: Boolean
        get() = sp.getBoolean("rsi", true)
        set(v) { sp.edit().putBoolean("rsi", v).apply() }

    var useMacd: Boolean
        get() = sp.getBoolean("macd", true)
        set(v) { sp.edit().putBoolean("macd", v).apply() }

    var useSr: Boolean
        get() = sp.getBoolean("sr", true)
        set(v) { sp.edit().putBoolean("sr", v).apply() }

    /** Прозрачность плавающего окна, 30..100 %. */
    var opacity: Int
        get() = sp.getInt("opacity", 90)
        set(v) { sp.edit().putInt("opacity", v).apply() }

    fun history(): List<Signal> {
        val raw = sp.getString("history", "[]") ?: "[]"
        val out = ArrayList<Signal>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Signal(
                        o.getLong("t"), o.getString("a"), o.getString("tf"),
                        o.getString("d"), o.getString("tr"), o.optString("n", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addHistory(s: Signal) {
        val list = ArrayList(history())
        list.add(0, s)
        val arr = JSONArray()
        for (item in list.take(MAX_HISTORY)) {
            arr.put(
                JSONObject()
                    .put("t", item.time).put("a", item.asset).put("tf", item.timeframe)
                    .put("d", item.direction).put("tr", item.trend).put("n", item.note)
            )
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    companion object {
        const val MAX_HISTORY = 50
        val ASSETS = listOf(
            "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD",
            "EUR/GBP", "BTC/USD", "ETH/USD", "Золото", "Другой"
        )
        val TIMEFRAMES = listOf("S30", "M1", "M2", "M3", "M5", "M15")
        val INTERVALS = listOf(2, 3, 5, 10, 15, 30)
    }
}
