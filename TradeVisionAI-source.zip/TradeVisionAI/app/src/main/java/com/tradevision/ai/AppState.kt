package com.tradevision.ai

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

data class Signal(
    val time: Long,
    val asset: String,
    val timeframe: String,
    val direction: String, // BUY / SELL / WAIT / NO DATA
    val trend: String,     // UP / DOWN / SIDEWAYS / —
    val note: String
)

object AppState {
    @Volatile var running = false
    @Volatile var paused = false
    @Volatile var last: Signal? = null

    val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun notifyChanged() {
        main.post { listeners.forEach { it() } }
    }
}
