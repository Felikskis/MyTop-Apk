package com.tradevision.ai

import android.content.Context
import android.graphics.drawable.GradientDrawable

object Ui {
    val BG = 0xFF0B0E11.toInt()
    val CARD = 0xFF151A21.toInt()
    val TEXT = 0xFFE6EDF3.toInt()
    val MUTED = 0xFF8A93A0.toInt()
    val ACCENT = 0xFF00E5A0.toInt()
    val BUY = 0xFF00C853.toInt()
    val SELL = 0xFFFF1744.toInt()
    val WAIT = 0xFFFFD600.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * c.resources.displayMetrics.density
        }

    fun dirColor(d: String): Int = when (d) {
        "BUY" -> BUY
        "SELL" -> SELL
        "WAIT" -> WAIT
        else -> MUTED
    }

    fun trendColor(t: String): Int = when (t) {
        "UP" -> BUY
        "DOWN" -> SELL
        "SIDEWAYS" -> WAIT
        else -> MUTED
    }
}
