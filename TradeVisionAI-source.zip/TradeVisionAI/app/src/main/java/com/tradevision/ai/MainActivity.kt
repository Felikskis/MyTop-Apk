package com.tradevision.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var tvStatus: TextView
    private lateinit var btnStart: TextView
    private lateinit var tvSignal: TextView
    private lateinit var tvSignalNote: TextView
    private lateinit var tvTrend: TextView
    private lateinit var tvTrendNote: TextView
    private lateinit var histBox: LinearLayout

    private val listener: () -> Unit = { refresh() }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        AppState.listeners.add(listener)
        refresh()
    }

    override fun onPause() {
        AppState.listeners.remove(listener)
        super.onPause()
    }

    // ---------- Запуск ----------

    private fun onStartClicked() {
        if (AppState.running) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Разрешите показ поверх других приложений и нажмите START ещё раз",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        requestCapture()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) requestCapture() // уведомления не обязательны для работы
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Анализ запущен. Откройте Pocket Option.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Разрешение на захват экрана не выдано", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Интерфейс ----------

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val p = Ui.dp(this, 16)
        root.setPadding(p, p, p, p)
        scroll.addView(root)

        // Логотип
        root.addView(text("TradeVision AI", 28f, Ui.ACCENT, bold = true))
        root.addView(text("Алгоритмический анализ графика на экране", 13f, Ui.MUTED))

        tvStatus = text("", 14f, Ui.TEXT)
        tvStatus.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 8))
        root.addView(tvStatus)

        btnStart = text("START ANALYSIS", 16f, 0xFF04130D.toInt(), bold = true)
        btnStart.gravity = Gravity.CENTER
        btnStart.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16))
        btnStart.background = Ui.rounded(this, Ui.ACCENT, 12)
        btnStart.setOnClickListener { onStartClicked() }
        root.addView(btnStart, margins(bottom = 12))

        // Карточка сигнала
        val sigCard = card()
        sigCard.addView(text("ПОСЛЕДНИЙ СИГНАЛ", 11f, Ui.MUTED))
        tvSignal = text("—", 36f, Ui.MUTED, bold = true)
        sigCard.addView(tvSignal)
        tvSignalNote = text("Сигналов пока нет", 12f, Ui.MUTED)
        sigCard.addView(tvSignalNote)

        // Карточка тренда
        val trCard = card()
        trCard.addView(text("ТРЕНД", 11f, Ui.MUTED))
        tvTrend = text("—", 24f, Ui.MUTED, bold = true)
        trCard.addView(tvTrend)
        tvTrendNote = text("", 12f, Ui.MUTED)
        trCard.addView(tvTrendNote)

        // Настройки
        val setCard = card()
        setCard.addView(text("НАСТРОЙКИ", 11f, Ui.MUTED))

        setCard.addView(text("Актив (выбирается вручную — с экрана не читается)", 12f, Ui.TEXT))
        setCard.addView(spinner(Prefs.ASSETS, prefs.asset) { prefs.asset = it })

        setCard.addView(text("Таймфрейм (вручную)", 12f, Ui.TEXT))
        setCard.addView(spinner(Prefs.TIMEFRAMES, prefs.timeframe) { prefs.timeframe = it })

        setCard.addView(text("Частота анализа", 12f, Ui.TEXT))
        setCard.addView(
            spinner(Prefs.INTERVALS.map { "$it сек" }, "${prefs.intervalSec} сек") {
                prefs.intervalSec = it.removeSuffix(" сек").toInt()
            }
        )

        val sensLabel = text("", 12f, Ui.TEXT)
        fun sensText(v: Int) = "Чувствительность: " + when (v) { 1 -> "низкая (меньше сигналов)"; 3 -> "высокая (больше сигналов)"; else -> "средняя" }
        sensLabel.text = sensText(prefs.sensitivity)
        setCard.addView(sensLabel)
        setCard.addView(seek(2, prefs.sensitivity - 1) { v ->
            prefs.sensitivity = v + 1
            sensLabel.text = sensText(v + 1)
        })

        setCard.addView(text("Индикаторы", 12f, Ui.TEXT))
        setCard.addView(check("EMA 9/21", prefs.useEma) { prefs.useEma = it })
        setCard.addView(check("RSI 14", prefs.useRsi) { prefs.useRsi = it })
        setCard.addView(check("MACD 12/26/9", prefs.useMacd) { prefs.useMacd = it })
        setCard.addView(check("Поддержка / сопротивление", prefs.useSr) { prefs.useSr = it })

        val opLabel = text("Прозрачность окна: ${prefs.opacity}%", 12f, Ui.TEXT)
        setCard.addView(opLabel)
        setCard.addView(seek(70, prefs.opacity - 30) { v ->
            prefs.opacity = v + 30
            opLabel.text = "Прозрачность окна: ${v + 30}%"
            AppState.notifyChanged()
        })

        // История
        val histCard = card()
        histCard.addView(text("ИСТОРИЯ СИГНАЛОВ", 11f, Ui.MUTED))
        histBox = LinearLayout(this)
        histBox.orientation = LinearLayout.VERTICAL
        histCard.addView(histBox)
        val clear = text("Очистить историю", 12f, Ui.SELL)
        clear.setPadding(0, Ui.dp(this, 10), 0, 0)
        clear.setOnClickListener { prefs.clearHistory(); refresh() }
        histCard.addView(clear)

        val warn = text(
            "Это не нейросеть и не торговая рекомендация. Приложение считает индикаторы по найденным на экране " +
                "свечам и не оценивает вероятность успеха. Сделки не совершаются, данные не покидают телефон. " +
                "Торговля бинарными опционами связана с высоким риском потери средств.",
            11f, Ui.MUTED
        )
        warn.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 24))

        root.addView(sigCard, margins(bottom = 12))
        root.addView(trCard, margins(bottom = 12))
        root.addView(setCard, margins(bottom = 12))
        root.addView(histCard, margins(bottom = 12))
        root.addView(warn)
        return scroll
    }

    private fun refresh() {
        val running = AppState.running
        btnStart.text = if (running) "ОСТАНОВИТЬ АНАЛИЗ" else "START ANALYSIS"
        btnStart.background = Ui.rounded(this, if (running) Ui.SELL else Ui.ACCENT, 12)
        btnStart.setTextColor(if (running) 0xFFFFFFFF.toInt() else 0xFF04130D.toInt())
        tvStatus.text = when {
            !running -> "○ Захват экрана: выключен"
            AppState.paused -> "● Захват экрана: включён (пауза)"
            else -> "● Захват экрана: включён"
        }
        tvStatus.setTextColor(if (running) Ui.ACCENT else Ui.MUTED)

        val s = AppState.last
        val dir = s?.direction ?: "—"
        tvSignal.text = dir
        tvSignal.setTextColor(Ui.dirColor(dir))
        tvSignalNote.text = if (s == null) "Сигналов пока нет"
        else "${s.asset} · ${s.timeframe} · ${fmt(s.time)}\n${s.note}"

        val tr = s?.trend ?: "—"
        tvTrend.text = tr
        tvTrend.setTextColor(Ui.trendColor(tr))
        tvTrendNote.text = when (tr) {
            "UP" -> "Восходящий"
            "DOWN" -> "Нисходящий"
            "SIDEWAYS" -> "Боковой"
            else -> ""
        }

        histBox.removeAllViews()
        val hist = prefs.history().take(20)
        if (hist.isEmpty()) {
            histBox.addView(text("Пока пусто", 12f, Ui.MUTED))
        } else {
            for (h in hist) {
                val row = text("${fmt(h.time)}  ${h.asset} ${h.timeframe}  ${h.direction}  ${h.trend}", 12f, Ui.dirColor(h.direction))
                row.setPadding(0, Ui.dp(this, 4), 0, 0)
                histBox.addView(row)
            }
        }
    }

    // ---------- Помощники ----------

    private fun fmt(t: Long): String = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date(t))

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
            background = Ui.rounded(this@MainActivity, Ui.CARD, 14)
        }

    private fun margins(bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = Ui.dp(this@MainActivity, bottom) }

    private fun spinner(items: List<String>, current: String, onSel: (String) -> Unit): Spinner {
        val sp = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(items.indexOf(current).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                onSel(items[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = progress
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) onChange(value)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        return sb
    }

    private fun check(label: String, value: Boolean, onChange: (Boolean) -> Unit): CheckBox =
        CheckBox(this).apply {
            text = label
            setTextColor(Ui.TEXT)
            isChecked = value
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }

    companion object {
        private const val REQ_CAPTURE = 100
        private const val REQ_NOTIF = 101
    }
}
